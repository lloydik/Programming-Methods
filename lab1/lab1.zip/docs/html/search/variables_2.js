var searchData=
[
  ['salary_0',['salary',['../classAccountant.html#a80c1852988fadda1058a176c3c57cc88',1,'Accountant']]],
  ['subdivision_1',['subdivision',['../classAccountant.html#a4c1b84dd1ab3ad6ba86bbc2a4238c039',1,'Accountant']]]
];
