var searchData=
[
  ['job_5ftitle_0',['job_title',['../classAccountant.html#a182b6a0b2be32b1a777e130fa9f81c93',1,'Accountant']]]
];
