var searchData=
[
  ['calc_5falgo_5ftime_0',['calc_algo_time',['../lab1_8cpp.html#af90c4eaa6dd815753b061b44a8538347',1,'lab1.cpp']]]
];
