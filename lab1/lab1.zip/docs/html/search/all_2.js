var searchData=
[
  ['full_5fname_0',['full_name',['../classAccountant.html#a890887777331fd6d5f35cf3cbde13112',1,'Accountant']]]
];
