var searchData=
[
  ['readfromfile_0',['readFromFile',['../lab1_8cpp.html#a4347593cfa06acd4fd51c118ad897052',1,'lab1.cpp']]]
];
