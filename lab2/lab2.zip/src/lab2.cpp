﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>
#include <string>
/*!
Реализовать поиск заданного элемента в массиве (необходимо найти ВСЕ вхождения) 
объектов по ключу в соответствии с вариантом (ключом является  первое НЕ числовое поле объекта) следующими методами:
- линейный поиск
- с помощью бинарного дерева поиска
- с помощью красно-черного дерева
- с помощью хэш таблицы
*/
class Accountant {
    // Вынес в паблик, чтобы не надо было определять геттеры
    public:
        //! ФИО служащего
        std::string full_name;
        //! Должность
        std::string job_title;
        //! Подразделение
        std::string subdivision;
        //! Месячная зарплата
        unsigned long salary;

        Accountant(std::string _full_name="", std::string _job_title="", std::string _subdivision="", unsigned long _salary=0)
        {
            this->full_name = _full_name;
            this->job_title = _job_title;
            this->subdivision = _subdivision;
            this->salary = _salary;
        }

        bool operator < (const Accountant& account) const
        {
            return (this->subdivision != account.subdivision) ? (this->subdivision < account.subdivision) : ((this->full_name != account.full_name) ? (this->full_name < account.full_name) : ((this->salary != account.salary) ? (this->salary < account.salary) : false));
        }

        bool operator == (const Accountant& account) const
        {
            return (this->subdivision == account.subdivision && this->salary == account.salary && this->job_title == account.job_title && this->full_name == account.full_name);
        }

        bool operator != (const Accountant& account) const
        {
            return !(*this == account);
        }

        bool operator <= (const Accountant& account) const
        {
            return *this == account || *this < account;
        }

        bool operator > (const Accountant& account) const
        {
            return !(*this <= account);
        }

        bool operator >= (const Accountant& account) const
        {
            return !(*this < account);
        }
};


/*!
 * @brief Структура бинарного дерева, на котором будем строить поиск
 *
 * Функция для записи в файл
 *
 * @param left Файловый поток для записи
 * @param func Функция алгоритма
 * @param fileStream Файловый поток для вывода алгоритма
 *
 */
struct tree {
    //! Левый узел
    tree* left;
    //! Правый узел
    tree* right;
    //! Ключ текущего узла (ФИО служащего)
    std::string key;
    //! Значение текущего узла
    Accountant obj;
    //! Индекс элемента в исходном массиве
    long index;  
};

/*!
 * @brief Поиск первого вхождения элемента
 *
 * Функция для поиска первого элемента по заданному ключу в поддереве root
 *
 * @param root Корень дерева или поддерева для поиска
 * @param key По какому ключу искать?
 *
 * @return Узел найденного элемента
*/

tree* search(tree* root, std::string key)
{
    if((root == NULL) || (root->key == key))
    {
        return root;
    }
    if(key < root->key)
        return search(root->left, key);
    return search(root->right, key);
}


/*!
 * @brief Поиск всех элементов
 *
 * Функция для поиска всех элементов по заданному ключу в поддереве root
 *
 * @param root Корень дерева или поддерева для поиска
 * @param key По какому ключу искать?
 * @param result[] Массив с результатом, в который будет записан результат выполнения алгоритма (индексы объектов с заданным ключом в массиве)
 * @param resultSize Размер массива result
*/
void searchAll(tree* root, std::string key, long result[], long& resultSize)
{
    tree* cur = NULL;
    tree* tmp = root;
    do
    {
        cur = search(tmp, key);
        if(!cur) break;
        result[resultSize] = cur->index;
        resultSize++;
        tmp = cur->right;
    } while(tmp);
}

/*!
 * @brief Очистка дерева
 *
 * Рекурсивная функция для освобождения памяти, занятой деревом
 *
 * @param root Корень дерева или поддерева для очистки
 */
void clearTree(tree* root)
{
    if (root == NULL)
        return;
        
    clearTree(root->left);   // Очищаем левое поддерево
    clearTree(root->right);  // Очищаем правое поддерево
    delete root;            // Удаляем текущий узел
}

std::ostream& operator << (std::ostream& os, const Accountant& account)
{
    return os << account.full_name << "; " << account.subdivision << "; " << account.job_title << "; " << account.salary;
}

std::istream& operator >> (std::istream& is, Accountant& account)
{
    std::string fullName, jobTitle, subdivision;
    unsigned long salary;
    std::getline(is, fullName);
    std::getline(is, jobTitle);
    std::getline(is, subdivision);
    is >> salary;
    is.ignore(); // Чтобы пропустить символ переноса строки из буффера
    account.full_name = fullName;
    account.job_title = jobTitle;
    account.subdivision = subdivision;
    account.salary = salary;
    return is;
}

/*!
 * @brief Чтение из файла
 *
 * Функция, считывающая данные из файла в массив
 *
 * @param myFile Поток файлового ввода
 * @param accountants[] Массив объектов Accountant
 * @param sample_size Размер массива
 *
 * @return Ничего. Массив сортируется внутри
 */
void readFromFile(std::fstream& myFile, Accountant accountants[], unsigned int sample_size)
{
    unsigned int i = 0;
    while (i < sample_size)
    {
        Accountant tmpObj;
        myFile >> tmpObj;
        if (!myFile)
            break;
        accountants[i] = tmpObj;
        ++i;
    }
}

template<class T>
/*!
 * @brief Линейный поиск
 *
 * Поиск проходится по всем элементам массива и сравнивает каждый элемент массива с переданным. Если совпали, то в переданный массив result заносится индекс найденного элемента. Ищутся все вхождения.
 *
 * @param a[] Массив элементов, в котором ищем элемент
 * @param size Размер массива
 * @param findElem Какой элемент ищем
 * @param result[] В него записываем индексы результата
 * @param resultSize Размер массива result
 *
 * @return Возвращает всегда 0. Обновиться массив result
 */
double linearSearch(T a[], long size, std::string findElem, long result[], long& resultSize)
{
    for (long i = 0; i < size; ++i)
    {
        if(a[i].full_name == findElem)
        {
            result[resultSize] = i;
            resultSize++;
        }
    }
    return 0.0;
}

template<class T>
/*!
 * @brief  Поиск в бинарном дереве
 *
 * Функция для создания бинарного дерева и поиска в нём

 * @param a[] Массив элементов, в котором ищем элемент
 * @param size Размер массива
 * @param findElem Какой элемент ищем
 * @param result[] В него записываем индексы результата
 * @param resultSize Размер массива result
 *
 * @return Обновиться массив result и вернётся время поиска элемента
 */
double binary_tree_adapter(T a[], long size, std::string findElem, long result[], long& resultSize) 
{
    tree* root = new tree();
    root->obj = a[0];
    root->key = a[0].full_name;
    root->left = NULL;
    root->right = NULL;
    root->index = 0;
    
    for(long i = 1; i < size; i++) {
        tree* newNode = new tree();
        newNode->obj = a[i];
        newNode->key = a[i].full_name;
        newNode->left = NULL;
        newNode->right = NULL;
        newNode->index = i;
        
        
        tree* current = root;
        tree* parent = NULL;

        // ищем место
        while(current != NULL) {
            parent = current;
            if(newNode->key < current->key)
                current = current->left;
            else
                current = current->right;
        }
        
        // вставляем
        if(newNode->key < parent->key)
            parent->left = newNode;
        else
            parent->right = newNode;
    }
    
    // Поиск элемента
    resultSize = 0;
    clock_t start = clock();
    // searchAll(root, findElem.full_name, result, resultSize);
    searchAll(root, findElem, result, resultSize);
    clock_t end = clock();
    
    // Очистка дерева
    clearTree(root);
    return (double)(end - start) / (double)(CLOCKS_PER_SEC);
}

template<class T>
/*!
 * @brief Подсчёт времени
 *
 * Функция для вычисления времени работы алгоритма
 *
 * @param func Функция с алгоритмом сортировки
 * @param a[] Массив элементов, который надо отсортировать
 * @param size Размер массива
 * @param findElem Элемент для поиска
 * @param result Массив с результатом
 * @param resultSize Размер массива с результатом
 *
 * @return Время работы алгоритма
 */
double calc_algo_time(double (*func)(T[], long, std::string, long[], long&), T a[], long size, std::string findElem, long result[], long& resultSize)
{
    clock_t start = clock();
    double t = func(a, size, findElem, result, resultSize);
    clock_t end = clock();
    return t ? t : ((double)(end - start) / (double)(CLOCKS_PER_SEC));
}

/*!
 * @brief Функция открытия файла
 *
 * Функция для вычисления времени работы алгоритма
 *
 * @param outFile Поток для открытия файла
 * @param filename Имя файла для открытия
 *
 * @return 500, если ошибка, иначе 0
 */
int openOutFile(std::fstream& outFile, std::string& filename)
{
    outFile.open(filename, std::ios::out);
    if (!outFile)
    {
        std::cerr << "Unable to open output file: " << filename;
        return 500;
    }
    return 0;
}

/*!
 * @brief Функция записи в файл
 *
 * Функция для записи в файл
 *
 * @param outFile Файловый поток для записи
 * @param a Массив, который надо записать
 * @param sample_size Размер массива
 *
 * @return Ничего
 */
template<class T>
void writeToFile(std::fstream& outFile, T* a, long sample_size)
{
    for (int i = 0; i < sample_size; ++i)
        outFile << "Сотрудник " << i + 1 << ": " << a[i] << std::endl;
}

/*!
 * @brief Структура для алгоритмов
 *
 * Функция для записи в файл
 *
 * @param name Файловый поток для записи
 * @param func Функция алгоритма
 * @param fileStream Файловый поток для вывода алгоритма
 *
 */
struct algoInfo {
    std::string name;
    double (*func)(Accountant[], long, std::string, long[], long&);
    std::fstream& fileStream;
    algoInfo(std::string name, double (*func)(Accountant[], long, std::string, long[], long&), std::fstream& fileStream) : name(name), func(func), fileStream(fileStream){}
};

/*!
 * @brief Структура красно-черного дерева
 */
struct RBTree {
    RBTree* left;
    RBTree* right;
    RBTree* parent;
    std::string key;      // ФИО служащего
    Accountant obj;       // Данные сотрудника
    long index;          // Индекс в исходном массиве
    bool color;          // true = красный, false = черный

    RBTree() : left(nullptr), right(nullptr), parent(nullptr), color(true) {}
};

/*!
 * @brief Левый поворот в красно-черном дереве
 */
void leftRotate(RBTree*& root, RBTree* k1) {
    // k2 на той картинке
    RBTree* k2 = k1->right;
    // B теперь цепляется к k1
    k1->right = k2->left;
    // Если B не nullptr, то B->parent = k1
    if (k2->left != nullptr) {
        k2->left->parent = k1;
    }
    // Меняем родителя в поддереве
    k2->parent = k1->parent;
    // Если x был корнем, то k2 теперь корень
    if (k1->parent == nullptr) {
        root = k2;
    } else if (k1 == k1->parent->left) {
        // Если k1 был левым ребенком, то k2 теперь левый ребенок
        k1->parent->left = k2;
    } else {
        // Если k1 был правым ребенком, то k2 теперь правый ребенок
        k1->parent->right = k2;
    }
    // Теперь k1 - левый потомок k2
    k2->left = k1;
    // Теперь k2 - родитель k1
    k1->parent = k2;
}

/*!
 * @brief Правый поворот в красно-черном дереве
 */
void rightRotate(RBTree*& root, RBTree* k1) {
    RBTree* k2 = k1->left;
    // B теперь цепляется к k1
    k1->left = k2->right;
    // Если B не nullptr, то B->parent = k2
    if (k2->right != nullptr) {
        k2->right->parent = k1;
    }
    // Меняем родителя в поддереве
    k2->parent = k1->parent;
    // Если k1 был корнем, то k2 теперь корень
    if (k1->parent == nullptr) {
        root = k2;
    } else if (k1 == k1->parent->right) {
        // Если k1 был правым потомок, то k2 теперь правый потомок
        k1->parent->right = k2;
    } else {
        // Если k1 был левым потомок, то k2 теперь левый потомок
        k1->parent->left = k2;
    }
    // Теперь k1 - правый потомок k2
    k2->right = k1;
    // Теперь k2 - родитель k1
    k1->parent = k2;
}

/*!
 * @brief Восстановление свойств красно-черного дерева после вставки
 *
 * Функция для восстановления свойств красно-черного дерева после вставки
 *
 * @param root Корень дерева
 * @param k Узел, который вставляем
 *
 * @return Ничего. Действия происходят в функции на деревом root
 */
void fixInsert(RBTree*& root, RBTree* k) {
    RBTree* u;
    // Пока Не дойдём до корня и родитель красный (перекраска идёт только жо этого момента)
    while (k->parent != nullptr && k->parent->color) {
        // Если родитель правый внук и красный
        if (k->parent == k->parent->parent->right) {
            u = k->parent->parent->left; // uncle - дядя
            if (u != nullptr && u->color) { // И дядя красный
                // Первый случай
                u->color = false; // Перекрашиваем дядю
                k->parent->color = false; // Перекрашиваем отца
                k->parent->parent->color = true; // Перекрашиваем деда
                k = k->parent->parent; // Переходим к дедушке и продолжаем восстанавливать свойства относительно него
            } else {
                // Если отец красный, а дядя - чёрный, то - второй случай с четырьмя подслучаями, 
                // но наш родитель - правый ребёнок, так что рассматривается случай г) и б)
                if (k == k->parent->left) { // Если вставляем влево, то поворачиваем вправо относительно отца
                    k = k->parent;
                    rightRotate(root, k);
                }
                // Дальше делаем то, что нужно только для случая б)
                // Перекрашиваем отца и деда
                k->parent->color = false;
                k->parent->parent->color = true;
                // Поворачиваем влево относительно деда
                leftRotate(root, k->parent->parent);
            }
        } else {
            // Если родитель левый ребенок, то смотрим случаи а) и в)
            u = k->parent->parent->right; // uncle - дядя
            if (u != nullptr && u->color) { // Дядя красный и отец красный
                // Первый случай. Просто повторяем его
                u->color = false; // Перекрашиваем дядю
                k->parent->color = false; // Перекрашиваем отца
                k->parent->parent->color = true; // Перекрашиваем деда
                k = k->parent->parent; // Переходим к дедушке и продолжаем восстанавливать свойства относительно него
            } else {
                // смотрим случаи а) и в)
                if (k == k->parent->right) { // Если вставляем вправо, то случай в)
                    // Поворачиваем влево относительно отца
                    k = k->parent;
                    leftRotate(root, k);
                }
                // Дальше делаем то, что нужно только для случая а)
                // Перекрашиваем отца и деда
                k->parent->color = false;
                k->parent->parent->color = true;
                // Поворачиваем вправо относительно деда
                rightRotate(root, k->parent->parent);
            }
        }
    }
    root->color = false; // Корень всегда чёрный
}

/*!
 * @brief Вставка узла в красно-черное дерево
 *
 * Функция для вставки узла в красно-черное дерево
 *
 * @param root Корень дерева
 * @param node Узел для вставки
 *
 * @return Ничего. Действия происходят в функции на дереве root
 */
void insert(RBTree*& root, RBTree* node) {
    RBTree* y = nullptr;
    RBTree* x = root;

    // Находим место для вставки
    while (x != nullptr) {
        y = x;
        if (node->key < x->key) {
            x = x->left;
        } else {
            x = x->right;
        }
    }

    // Вставляем узел
    node->parent = y;
    if (y == nullptr) {
        root = node;
    } else if (node->key < y->key) {
        y->left = node;
    } else {
        y->right = node;
    }

    // Восстанавливаем свойства красно-черного дерева
    fixInsert(root, node);
}

/*!
 * @brief Поиск в красно-черном дереве
 *
 * Функция для поиска в красно-черном дереве
 *
 * @param root Корень дерева
 * @param key Ключ для поиска
 *
 * @return Указатель на узел, если он найден, иначе nullptr
 */
RBTree* search(RBTree* root, const std::string key) {
    if (root == nullptr || root->key == key) {
        return root;
    }
    if (key < root->key) {
        return search(root->left, key);
    }
    return search(root->right, key);
}

/*!
 * @brief Поиск всех вхождений в красно-черном дереве
 *
 * Функция для поиска всех вхождений в красно-черном дереве
 *
 * @param root Корень дерева
 * @param key Ключ для поиска
 * @param result Массив для хранения результата
 * @param resultSize Размер массива для хранения результата
 *
 * @return Ничего. Действия происходят в функции и результат пишется в массив result
 */
void searchAll(RBTree* root, const std::string key, long result[], long& resultSize) {
    RBTree* current = root;
    while (current != nullptr) {
        if (key < current->key) {
            current = current->left;
        } else if (key > current->key) {
            current = current->right;
        } else {
            // Нашли совпадение
            result[resultSize] = current->index;
            resultSize++;
            // Ищем в правом поддереве, так как равные элементы находятся там
            current = current->right;
        }
    }
}

/*!
 * @brief Очистка красно-черного дерева
 */
void clearRBTree(RBTree* root) {
    if (root == nullptr) return;
    clearRBTree(root->left);
    clearRBTree(root->right);
    delete root;
}

template<class T>
/*!
 * @brief Адаптер для поиска в красно-черном дереве
 *
 * Адаптер для функции поиска в красно-черном дереве
 *
 * @param a[] Массив элементов
 * @param size Размер массива
 * @param findElem Ключ для поиска
 * @param result Массив для хранения результата
 * @param resultSize Размер массива для хранения результата
 *
 * @return Время
 */
double red_black_tree_adapter(T a[], long size, std::string findElem, long result[], long& resultSize) {
    RBTree* root = nullptr;
    
    // Создаем красно-черное дерево
    for (long i = 0; i < size; i++) {
        RBTree* node = new RBTree();
        node->obj = a[i];
        node->key = a[i].full_name;
        node->index = i;
        insert(root, node);
    }
    
    // Поиск элемента
    resultSize = 0;
    clock_t start = clock();
    searchAll(root, findElem, result, resultSize);
    clock_t end = clock();
    
    // Очистка дерева
    clearRBTree(root);
    return (double)(end - start) / (double)(CLOCKS_PER_SEC);
}

int main(int argc, char* argv[])
{
    if (argc != 2)
    {
        std::cerr << "Usage ./lab2 <count of files in tests directory>";
        return 400;
    }
    setlocale(LC_ALL, "Russian");

    std::fstream analyticsFile;
    std::string analyticsFilename = "analytics.txt";
    analyticsFile.open(analyticsFilename, std::ios::out);
    for (int test_id = 0; test_id < std::stoi(argv[1]); ++test_id)
    {
        std::fstream inFile;
        std::string inFilename = "tests/test_" + std::to_string(test_id) + ".txt";
        inFile.open(inFilename, std::ios::in);
        if (!inFile)
        {
            std::cerr << "Unable to open file: " << inFilename;
            return 500;
        }

        std::fstream outFileA, outFileB, outFileC, outFileD, outFileReal;
        std::string outFilenameA = "results/result_a_" + std::to_string(test_id) + ".txt";
        std::string outFilenameB = "results/result_b_" + std::to_string(test_id) + ".txt";
        std::string outFilenameC = "results/result_c_" + std::to_string(test_id) + ".txt";
        // std::string outFilenameD = "results/result_d_" + std::to_string(test_id) + ".txt";
        // std::string outFilenameReal = "results/result_real_" + std::to_string(test_id) + ".txt";
        if(openOutFile(outFileA, outFilenameA) == 500 || openOutFile(outFileB, outFilenameB) == 500 || openOutFile(outFileC, outFilenameC) == 500)// || openOutFile(outFileC, outFilenameC) == 500 || openOutFile(outFileReal, outFilenameReal) == 500)
        {
            std::cerr << "UNABLE TO OPEN FILE" << std::endl;
            return 500;
        }

        unsigned int sample_size = 0;
        inFile >> sample_size;
        inFile.ignore(); // Чтобы пропустить символ переноса строки из буффера

        Accountant* accountants = new Accountant[sample_size];
        Accountant* accountantsBackup = new Accountant[sample_size];
        long result[1000000] = { 0 }; // Больше этого точно не будет
        long resultSize = 0;

        readFromFile(inFile, accountants, sample_size);
        
        srand(time(0));
        long real_idx = rand() % sample_size;
        // Accountant findElem = accountants[real_idx];
        std::string findElem = accountants[real_idx].full_name;

        // Создаём бэкап для восстановления массива
        std::copy(accountants, accountants + sample_size, accountantsBackup);
        std::vector<algoInfo> algos_arr = {algoInfo("Линейный поиск", linearSearch, outFileA), algoInfo("Бинарное дерево", binary_tree_adapter, outFileB), algoInfo("Красно-черное дерево", red_black_tree_adapter, outFileC)};
        analyticsFile << sample_size;
        for(int i = 0; i < algos_arr.size(); ++i)
        {
            // Считаем время поиска
            double algo_time = calc_algo_time(algos_arr[i].func, accountants, sample_size, findElem, result, resultSize);
            std::cout << algos_arr[i].name << " под номером " << test_id << " " << sample_size << " элементов " << " заняла: " << algo_time << " секунд" << std::endl;
            writeToFile(algos_arr[i].fileStream, result, resultSize);
            analyticsFile << " " << algo_time;

            // Возвращаем исходный массив
            std::copy(accountantsBackup, accountantsBackup + sample_size, accountants);
        }
        // std::cout << "РЕАЛЬНЫЙ ИНДЕКС: " << real_idx << std::endl;
        // std::cout << "РЕАЛЬНЫЙ ФИО: " << findElem << std::endl;
        analyticsFile << std::endl;
        delete [] accountantsBackup;
        delete [] accountants;
    }
    return 0;
}